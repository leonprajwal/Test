import os
import random
import time
import psutil
import pandas as pd
from openpyxl import load_workbook
from openpyxl.utils.dataframe import dataframe_to_rows


def handle_open_file(file_path, max_retries=3, delay=2):
    def is_file_open(file_path):
        for proc in psutil.process_iter(attrs=['pid', 'name']):
            try:
                for file in proc.open_files():
                    if file.path == file_path:
                        return True
            except Exception as e:
                pass
        return False

    def close_file_if_open(file_path):
        for proc in psutil.process_iter(attrs=['pid', 'name']):
            try:
                for file in proc.open_files():
                    if file.path == file_path:
                        proc.terminate()  # Use terminate() instead of kill() for a softer approach
                        proc.wait(timeout=3)  # Wait up to 3 seconds for the process to be terminated
                        print(f"Closed process {proc.pid} ({proc.name()}) that had the file open.")
            except Exception as e:
                pass

    retries = 0
    while is_file_open(file_path) and retries < max_retries:
        close_file_if_open(file_path)
        time.sleep(delay)  # Wait for some time to ensure file closure if needed
        retries += 1

    if retries == max_retries:
        print(f"Could not close file '{file_path}' after {max_retries} attempts.")


def process_participants(file_path, sheet_name_ind, sheet_name_usa):
    # Load the workbook
    wb = load_workbook(file_path)

    # Check if the sheets exist and delete them if they do
    if sheet_name_ind in wb.sheetnames:
        del wb[sheet_name_ind]

    if sheet_name_usa in wb.sheetnames:
        del wb[sheet_name_usa]

    # Save the workbook after deleting the sheets
    wb.save(file_path)

    # Read the Excel file into a DataFrame
    df = pd.read_excel(file_path, sheet_name=sheet_name)

    # Strip any leading/trailing spaces from the column names
    df.columns = df.columns.str.strip()

    # Filter the DataFrame to include only rows where the 'country' column is 'India'
    df_india = df[df['Country'] == 'INDIA']
    df_others = df[df['Country'] != 'INDIA']

    # Save the filtered DataFrame to new sheets in the same Excel file
    with pd.ExcelWriter(file_path, engine='openpyxl', mode='a') as writer:
        df_india.to_excel(writer, sheet_name='India Participants', index=False)
        print("Filtered data has been written to 'India Participants' sheet successfully.")
        # with pd.ExcelWriter(file_path, engine='openpyxl', mode='a') as writer:
        df_others.to_excel(writer, sheet_name='USA Participants', index=False)
        print("Filtered data has been written to 'USA Participants' sheet successfully.")


def create_teams(file_path, sheet_name):
    # Load the workbook
    wb = load_workbook(file_path)

    # Check if the sheet exists and delete it if it does
    if 'Teams Participants' in wb.sheetnames:
        del wb['Teams Participants']

    # Save the workbook after deleting the sheet
    wb.save(file_path)

    # Read the "India Participants" sheet into a DataFrame
    df_india = pd.read_excel(file_path, sheet_name=sheet_name)

    # Column name for roles
    roles_column = "What additional skill or experience will you bring to the team? if using other, please place a comma after each skill (I.E Python, Excel, Power BI, Customer Empathy, Project Management... etc)."

    # Function to check if a participant has a specific role
    def has_role(roles, role):
        return role in roles.split(';')

    # Filter participants into developers and problem solvers
    developers = df_india[df_india[roles_column].apply(lambda x: has_role(x, 'Development'))]
    problem_solvers = df_india[df_india[roles_column].apply(lambda x: has_role(x, 'Problem Solving'))]

    # Initialize teams
    teams = []
    team_id = 1
    assigned_participants = set()  # Set to track already assigned participants

    # Ensure each team has a developer and a problem solver
    while not developers.empty and not problem_solvers.empty:
        team = {'Team Name': f'Team {team_id:02}'}

        # Add one developer
        developer = developers.iloc[0]
        if developer['Name'] not in assigned_participants:
            team['Developer'] = developer
            assigned_participants.add(developer['Name'])
            developers = developers.iloc[1:]
        else:
            developers = developers.iloc[1:]

        # Add one problem solver
        problem_solver = problem_solvers.iloc[0]
        if problem_solver['Name'] not in assigned_participants:
            team['Problem Solver'] = problem_solver
            assigned_participants.add(problem_solver['Name'])
            problem_solvers = problem_solvers.iloc[1:]
        else:
            problem_solvers = problem_solvers.iloc[1:]

        # Exclude already assigned participants from the additional roles pool
        taken_participants = assigned_participants
        additional_pool = df_india[~df_india['Name'].isin(taken_participants)]

        # Add up to three additional members from any role
        if not additional_pool.empty:
            team['Additional 1'] = additional_pool.iloc[0]
            assigned_participants.add(additional_pool.iloc[0]['Name'])
            additional_pool = additional_pool.iloc[1:]

        if not additional_pool.empty:
            team['Additional 2'] = additional_pool.iloc[0]
            assigned_participants.add(additional_pool.iloc[0]['Name'])
            additional_pool = additional_pool.iloc[1:]

        if not additional_pool.empty:
            team['Additional 3'] = additional_pool.iloc[0]
            assigned_participants.add(additional_pool.iloc[0]['Name'])
            additional_pool = additional_pool.iloc[1:]

        teams.append(team)
        team_id += 1

    # Convert teams to DataFrame
    team_data = []

    for team in teams:
        row = {
            'Team Name': team['Team Name'],
            'Developer': team['Developer']['Name'] if 'Developer' in team else 'N/A',
            'Problem Solver': team['Problem Solver']['Name'] if 'Problem Solver' in team else 'N/A',
            'Additional 1': team['Additional 1']['Name'] if 'Additional 1' in team else 'N/A',
            'Additional 2': team['Additional 2']['Name'] if 'Additional 2' in team else 'N/A',
            'Additional 3': team['Additional 3']['Name'] if 'Additional 3' in team else 'N/A'
        }
        team_data.append(row)

    df_teams = pd.DataFrame(team_data)

    # Print teams information (optional)
    print(df_teams)

    # Optionally return df_teams if you want to further process it in your script

    # Example of saving to a new sheet (commented out)
    with pd.ExcelWriter(file_path, engine='openpyxl', mode='a') as writer:
        df_teams.to_excel(writer, sheet_name='Teams Participants', index=False)

    print("Teams Participants have been created successfully.")


def create_participates(file_path, sheet_name, roles_column, update_sheet):
    # Load the workbook
    wb = load_workbook(file_path)

    # Check if the sheet exists and delete it if it does
    if update_sheet in wb.sheetnames:
        del wb[update_sheet]

    # Save the workbook after deleting the sheet
    wb.save(file_path)

    # Read the "India Participants" sheet into a DataFrame
    df_india = pd.read_excel(file_path, sheet_name=sheet_name)

    # Define roles column
    # roles_column = "What additional skill or experience will you bring to the team? if using other, please place a comma after each skill (I.E Python, Excel, Power BI, Customer Empathy, Project Management... etc)."

    # Function to extract names based on roles
    def get_names_by_role(df, role):
        names = df[df[roles_column].apply(lambda x: role in x.split(';'))]['Email'].unique()
        return names

    # Extract developer names
    developers = get_names_by_role(df_india, 'Development')
    developers = developers if developers is not None else []
    print(developers)

    # Extract problem solver names
    problem_solvers = get_names_by_role(df_india, 'Problem Solving')
    problem_solvers = problem_solvers if problem_solvers is not None else []
    print(problem_solvers)

    # Extract remaining roles as member names
    taken_names = set(developers).union(set(problem_solvers))
    remaining_members = df_india[~df_india['Email'].isin(taken_names)]['Email'].unique()
    remaining_members = remaining_members if remaining_members is not None else []
    print(type(remaining_members))

    #
    # Determine the maximum length among the arrays
    max_length = max(len(developers), len(problem_solvers), len(remaining_members))

    # Create a DataFrame with maximum length and assign values
    participates_df = pd.DataFrame({
        'Developer Names': [developers[i] if i < len(developers) else pd.NA for i in range(max_length)],
        'Problem Solver Names': [problem_solvers[i] if i < len(problem_solvers) else pd.NA for i in range(max_length)],
        'Remaining Member Names': [remaining_members[i] if i < len(remaining_members) else pd.NA for i in
                                   range(max_length)]
    })
    print(participates_df)
    # Save extracted names to a new sheet in the same Excel file
    with pd.ExcelWriter(file_path, engine='openpyxl', mode='a') as writer:
        participates_df.to_excel(writer, sheet_name=update_sheet, index=False)

    print("Email extracted and saved to 'Participates' sheet successfully.")


def rearrange_rows(input_file, sheet_name, column_name):
    # Load the workbook
    wb = load_workbook(input_file)

    # Select the sheet
    sheet = wb[sheet_name]

    # List to store rows with data and empty rows separately
    rows_with_data = []
    empty_rows = []

    # Iterate through rows
    for row in sheet.iter_rows(values_only=True):
        if any(row):  # Check if the row has any data
            rows_with_data.append(row)
        else:
            empty_rows.append(row)

    # Clear the existing sheet
    sheet.delete_rows(1, sheet.max_row)

    # Add column header
    if rows_with_data:
        header_row = [column_name]  # Create a list with the column name
        sheet.append(header_row)

    # Write rows with data first
    for row in rows_with_data:
        sheet.append(row)

    # Write empty rows at the end
    for row in empty_rows:
        sheet.append(row)

    # Save the workbook (overwrite the original file)
    wb.save(input_file)

    print(f"Rows rearranged successfully in '{input_file}'.")


def remove_duplicates_and_compare(file_path, sheet_name='Participates', update_sheet='Dupl_removed'):
    wb = load_workbook(file_path)

    # Check if the 'Participates' sheet exists
    if sheet_name not in wb.sheetnames:
        print(f"Error: Sheet 'Participates' not found in '{file_path}'.")
        return
    if update_sheet in wb.sheetnames:
        del wb[update_sheet]

    wb.save(file_path)
    # Read 'Participates' sheet into a DataFrame
    df_participates = pd.read_excel(file_path, sheet_name=sheet_name)

    # Convert 'nan' strings to actual NaN values (if any)
    df_participates.replace('nan', pd.NA, inplace=True, regex=True)

    # Extract lists for 'Developer Names', 'Problem Solver Names', and 'Remaining Member Names'
    developers = df_participates['Developer Names'].dropna().unique().tolist()
    problem_solvers = df_participates['Problem Solver Names'].dropna().unique().tolist()
    remaining_members = df_participates['Remaining Member Names'].dropna().unique().tolist()

    # Function to remove duplicates between two lists
    def remove_duplicates_in_place(source_list, target_list):
        if source_list and target_list:
            target_set = set(target_list)
            source_list[:] = [item for item in source_list if item not in target_set]

    # Remove duplicates based on the described rules
    if developers and problem_solvers:
        remove_duplicates_in_place(problem_solvers, developers)

    if developers and remaining_members:
        remove_duplicates_in_place(remaining_members, developers)

    if problem_solvers and remaining_members:
        remove_duplicates_in_place(remaining_members, problem_solvers)

    # Update the DataFrame with the modified lists
    df_participates['Developer Names'] = df_participates['Developer Names'].apply(
        lambda x: x if x in developers else pd.NA)
    df_participates['Problem Solver Names'] = df_participates['Problem Solver Names'].apply(
        lambda x: x if x in problem_solvers else pd.NA)
    df_participates['Remaining Member Names'] = df_participates['Remaining Member Names'].apply(
        lambda x: x if x in remaining_members else pd.NA)
    print("===================")
    print(df_participates)
    # Save the modified 'Participates' sheet back to Excel
    with pd.ExcelWriter(file_path, engine='openpyxl', mode='a') as writer:
        df_participates.to_excel(writer, sheet_name=update_sheet, index=False)

    # rearrange_rows(file_path, 'Dupl_removed', 'Developer Names')
    # print('dev')
    # rearrange_rows(file_path, 'Dupl_removed', 'Problem Solver Names')
    # print("prob")
    # rearrange_rows(file_path, 'Dupl_removed', 'Remaining Member Names')

    # Print the updated DataFrame for verification
    print("===================")
    print(df_participates)


def extract_non_empty_data_from_excel(file_path, sheet_name):
    df = pd.read_excel(file_path, sheet_name=sheet_name)

    # Initialize lists
    developer_names = []
    problem_solver_names = []
    remaining_member_names = []

    # Iterate through each row
    for index, row in df.iterrows():
        # Developer Names column
        if pd.notna(row['Developer Names']):
            developer_names.append(row['Developer Names'])

        # Problem Solver Names column
        if pd.notna(row['Problem Solver Names']):
            problem_solver_names.append(row['Problem Solver Names'])

        # Remaining Member Names column
        if pd.notna(row['Remaining Member Names']):
            remaining_member_names.append(row['Remaining Member Names'])
    print("Developer Names:", developer_names)
    print("Problem Solver Names:", problem_solver_names)
    print("Remaining Member Names:", remaining_member_names)
    return developer_names, problem_solver_names, remaining_member_names


def create_and_write_teams(file_path, developers, problem_solvers, remaining_members, Teams_sheet='Team div'):
    wb = load_workbook(file_path)
    if Teams_sheet in wb.sheetnames:
        del wb[Teams_sheet]
    wb.save(file_path)

    teams = []
    team_number = 1

    # Main loop to create teams with up to 5 members
    while developers or problem_solvers or remaining_members:
        team = {'Team Name': f'Team {team_number:03}', 'Members': []}
        if developers:
            team['Members'].append(developers.pop(0))
        if problem_solvers:
            team['Members'].append(problem_solvers.pop(0))
        if remaining_members:
            team['Members'].append(remaining_members.pop(0))

        # Fill the team with remaining members up to 5
        while len(team['Members']) < 5 and (developers or problem_solvers or remaining_members):
            if remaining_members:
                team['Members'].append(remaining_members.pop(0))
            elif problem_solvers:
                team['Members'].append(problem_solvers.pop(0))
            elif developers:
                team['Members'].append(developers.pop(0))

        teams.append(team)
        team_number += 1

    # Handle leftover members if any team has less than 6 members
    for leftover in (developers + problem_solvers + remaining_members):
        for team in teams:
            if len(team['Members']) < 6:
                team['Members'].append(leftover)
                break

    # Convert the list of teams into a DataFrame
    df_teams = pd.DataFrame([{
        'Team Name': team['Team Name'],
        **{f'Member {i + 1}': member for i, member in enumerate(team['Members'])}
    } for team in teams])
    print(df_teams)
    # Append DataFrame to Excel file
    with pd.ExcelWriter(file_path, engine='openpyxl', mode='a') as writer:
        df_teams.to_excel(writer, sheet_name=Teams_sheet, index=False)

    print("Team created and updated to Excel file successfully.")
    print("=====================================================")


def process_hackathon_data(file_path, team_sheet_name='Teams', participant_sheet_name='Participants',
                           final_sheet_name='Final_Team_Data_India'):
    try:
        # Load the workbook
        wb = load_workbook(file_path)

        # Check if the final sheet already exists, delete it if it does
        if final_sheet_name in wb.sheetnames:
            print(f"Sheet '{final_sheet_name}' already exists. Deleting the sheet...")
            del wb[final_sheet_name]
            print(f"Sheet '{final_sheet_name}' has been deleted.")

        # Save the workbook to apply changes
        wb.save(file_path)
        print(f"Workbook saved successfully after deleting '{final_sheet_name}'.")

        # Read dataframes again after potential changes
        teams_df = pd.read_excel(file_path, sheet_name=team_sheet_name)
        participants_df = pd.read_excel(file_path, sheet_name=participant_sheet_name)

        # Create a new Excel writer object
        with pd.ExcelWriter(file_path, engine='openpyxl', mode='a') as writer:
            # Write teams data first
            teams_df.to_excel(writer, sheet_name=team_sheet_name, index=False)

            # Write participants data next
            participants_df.to_excel(writer, sheet_name=participant_sheet_name, index=False)

            # Initialize start row for final team data
            start_row = 0

            # Process each team
            for index, row in teams_df.iterrows():
                team_name = row['Team Name']
                team_emails = [row[f'Member {i}'] for i in range(1, 6)]
                team_emails = [email for email in team_emails if pd.notna(email)]

                # Filter participants for the current team
                team_participants = participants_df[participants_df['Email'].isin(team_emails)]

                # Write the filtered data to the final sheet if team is from India
                if not team_participants.empty:
                    team_country = row['Country']  # Assuming 'Country' column exists in teams_df
                    if team_country == 'INDIA':
                        team_participants.to_excel(writer, sheet_name=final_sheet_name, index=False, startrow=start_row)
                        start_row += len(
                            team_participants) + 2  # Move start_row for the next team, leaving 2 empty rows

        print(f"Data written to '{final_sheet_name}' successfully.")

    except Exception as e:
        print(f"Error occurred: {e}")


def process_teams(file_path, sheet_name ,sheet_name_participants, sheet_name_final):
    wb = load_workbook(file_path)
    if sheet_name_final in wb.sheetnames:
        print(f"Sheet '{sheet_name_final}' already exists. Deleting the sheet...")
        del wb[sheet_name_final]
        print(f"Sheet '{sheet_name_final}' has been deleted.")

    # Save the workbook to apply changes
    wb.save(file_path)

    xls = pd.ExcelFile(file_path)

    # Load the "Team" sheet into a DataFrame
    df_teams = pd.read_excel(xls, sheet_name)

    # Create a list of teams and their members
    teams = df_teams.columns[1:].tolist()

    # Create a new Excel writer object
    writer = pd.ExcelWriter(file_path, engine='openpyxl')
    writer.book = load_workbook(file_path)

    # Process each team
    for team in teams:
        # Get the team member email addresses
        team_members = df_teams[team].dropna().tolist()

        # Filter the email data for each team from another sheet (assume 'EmailData' sheet)
        df_email_data = pd.read_excel(xls, sheet_name_participants)
        filtered_data = df_email_data[df_email_data['Email'].isin(team_members)]

        # Write the filtered data to the "final" sheet, with two empty columns between each team's data
        start_col = len(writer.sheets['final'].columns) if 'final' in writer.sheets else 0
        filtered_data.to_excel(writer, sheet_name_final, startcol=start_col + (start_col > 0) * 2, index=False)

    # Save the changes
    writer.save()


# Example usage


roles_column = "What additional skill or experience will you bring to the team? if using other, please place a comma after each skill (I.E Python, Excel, Power BI, Customer Empathy, Project Management... etc)."
file_path = "2024 Lumen Innovation Hackathon - Participants - Registration Masterlist.xlsx"
sheet_name = 'Participant mstr'
# handle_open_file(file_path)
process_participants(file_path, "India Participants", "USA Participants")
create_participates(file_path, "India Participants", roles_column, 'participates_India')
remove_duplicates_and_compare(file_path, 'participates_India', 'Dupl_removed_India')
developer_names, problem_solver_names, remaining_member_names = extract_non_empty_data_from_excel(file_path,
                                                                                                  'Dupl_removed_India')
create_and_write_teams(file_path, developer_names, problem_solver_names, remaining_member_names, 'Team div India')
process_teams(file_path, 'Team div India', 'Participant mstr', 'India_Final_Team_Data')
# process_hackathon_data(file_path, 'Team div India','India Participants',
#                         'India_Final_Team_Data')
# filter_teams_to_excel_in_same_file(file_path, 'Team div India')
# merge_team_data(file_path)
#
#
#
# create_participates(file_path, "USA Participants", roles_column, 'participates_USA')
# remove_duplicates_and_compare(file_path, 'participates_USA', 'Dupl_removed_USA')
# developer_names, problem_solver_names, remaining_member_names = extract_non_empty_data_from_excel(file_path,
#                                                                                                   'Dupl_removed_USA')
# create_and_write_teams(file_path, developer_names, problem_solver_names, remaining_member_names, 'Team div USA')
# # create_teams(file_path, "India Participants")
