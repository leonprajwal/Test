import requests
from timezonefinder import TimezoneFinder

import openpyxl


def collect_data_from_excel(filename, column):
    # Open the Excel file
    wb = openpyxl.load_workbook(filename)
    sheet = wb.active

    # List to store data from the specified column
    data = []

    # Loop through the rows in the specified column until an empty cell is encountered
    for cell in sheet[column]:
        if cell.value is not None:
            data.append(cell.value)
        else:
            break  # Break the loop when an empty cell is encountered

    return data


def get_location(pin_code):
    # Querying location details using pin code
    print(pin_code)
    url = f"https://nominatim.openstreetmap.org/search?q={pin_code}&format=json"
    print(url)
    response = requests.get(url)
    print(response.status_code)
    if response.status_code == 200:
        data = response.json()
        print(data)
        if data:
            location = data[0]  # Assuming the first result is the most relevant
            print("hello")
            return {
                "latitude": float(location["lat"]),
                "longitude": float(location["lon"]),
                "address": location["display_name"]
            }
    return None


def get_timezone(latitude, longitude):
    # Querying timezone based on latitude and longitude
    print("hi")
    tf = TimezoneFinder()
    time_zone = tf.timezone_at(lat=latitude, lng=longitude)
    if time_zone:
        continent = time_zone.split("/")[0]  # Extract continent from timezone identifier
        return continent
    else:
        return None


filename = "2024 Lumen Innovation Hackathon - Participants - Registration Masterlist.xlsx"
column = "T"
# Example usage
data_1 = collect_data_from_excel(filename, column)
if data_1:
    print("Data collected from column {}: {}".format(column, data_1))
else:
    print("No data found in column {} of the Excel file.".format(column))
location_info = get_location(data_1)
if location_info:
    latitude = location_info["latitude"]
    print(latitude)
    longitude = location_info["longitude"]
    print(longitude)
    address = location_info["address"]
    print(address)
    timezone = get_timezone(latitude, longitude)
    print(timezone)
    if timezone:
        print(f"Address: {address}")
        print(f"Latitude: {latitude}, Longitude: {longitude}")
        print(f"Timezone: {timezone}")
    else:
        print("Timezone not found for the given location.")
else:
    print("Location not found for the given pin code.")
