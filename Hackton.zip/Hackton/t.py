import requests
from timezonefinder import TimezoneFinder
import openpyxl
import pandas as pd
from openpyxl import load_workbook


def collect_data_from_excel(filename, column):
    # Open the Excel file
    wb = openpyxl.load_workbook(filename)
    sheet = wb.active

    # List to store data from the specified column
    data = []

    # Loop through the rows in the specified column until an empty cell is encountered
    for cell in sheet[column]:
        if cell.value is not None:
            data.append(cell.value)
        else:
            break  # Break the loop when an empty cell is encountered

    return data

def get_location(pin_code):
    # Querying location details using pin code
    url = f"https://nominatim.openstreetmap.org/search?q={pin_code}&format=json"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        if data:
            location = data[0]  # Assuming the first result is the most relevant
            return {
                "latitude": float(location["lat"]),
                "longitude": float(location["lon"]),
                "address": location["display_name"]
            }
    return "hi"

def get_timezone(latitude, longitude):
    # Querying timezone based on latitude and longitude
    tf = TimezoneFinder()
    timezone = tf.timezone_at(lat=latitude, lng=longitude)
    if timezone:
        continent = timezone.split("/")[0]  # Extract continent from timezone identifier
        print(continent)
        return continent
    else:
        return None

def add_timezone_to_excel(filename, column, timezone_column):
    # Open the Excel file
    wb = openpyxl.load_workbook(filename)
    sheet = wb.active

    # Collect data from the specified column
    data = collect_data_from_excel(filename, column)

    # Write timezone to new column in the Excel file
    for i, pin_code in enumerate(data, start=1):
        print(pin_code)
        location_info = get_location(pin_code)
        if location_info != "hi":
            latitude = location_info["latitude"]
            longitude = location_info["longitude"]
            timezone = get_timezone(latitude, longitude)
            # print(timezone)
            if timezone:
                sheet[timezone_column + str(i)] = timezone



    # Save the changes to the Excel file
    wb.save(filename)



def divide_and_append_by_country(input_file, sheet_name):

    excel_data = pd.read_excel(input_file, sheet_name=sheet_name)

    grouped = excel_data.groupby('country')

    book = load_workbook(input_file)

    existing_sheets = book.sheetnames
    for sheet in existing_sheets:
        if sheet in grouped.groups.keys():
            del book[sheet]

    with pd.ExcelWriter(input_file, engine='openpyxl', mode='a') as writer:
        writer.book = book

        for country, group in grouped:
            # Sanitize the sheet name
            new_sheet_name = ''.join([c if c.isalnum() else '_' for c in country])
            # Write the data to a sheet named after the country
            group.to_excel(writer, sheet_name=new_sheet_name, index=False)

        writer.save()


#



# Example usage
filename = "2024 Lumen Innovation Hackathon - Participants - Registration Masterlist.xlsx"
column = "U"
timezone_column = "Z"
sheet_name = 'Participant mstr'  # the sheet name you want to read from
divide_and_append_by_country(filename, sheet_name)
add_timezone_to_excel(filename, column, timezone_column)

